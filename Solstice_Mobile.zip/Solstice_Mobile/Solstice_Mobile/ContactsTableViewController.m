//
//  ContactsTableViewController.m
//  Solstice_Mobile
//
//  Created by Mayank Mathur on 3/2/17.
//  Copyright © 2017 Mayank Mathur. All rights reserved.
//

#import "ContactsTableViewController.h"
#import "ContactDetailsViewController.h"

// Main feed url
#define FEEDURL @"https://s3.amazonaws.com/technical-challenge/Contacts_v2.json"

@interface ContactsTableViewController ()

@end

@implementation ContactsTableViewController

static NSString * const reuseIdentifier = @"Cell";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // fetching feeds
    [self sendRequest:FEEDURL];
}

-(void)sendRequest:(NSString*)url{
    
    // fetching data in background thread
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:url]];
    [request setHTTPMethod:@"GET"];
    
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    [[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        // when performing UI changes, its should be done on a main thread
        [self performSelectorOnMainThread:@selector(fetchedData:)
                               withObject:data waitUntilDone:YES];
    }] resume];
    
}


- (void)fetchedData:(NSData *)responseData {
    //parse out the json data
    NSError* error;
    contactsArray = [NSJSONSerialization
                     JSONObjectWithData:responseData
                     options:kNilOptions
                     error:&error];

    
    // Reload table here
    [_contactsTableView reloadData];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark <UITableViewDataSource>

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [contactsArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                                   reuseIdentifier:CellIdentifier];
    
    if (contactsArray[indexPath.row] != nil)
    {
        // To fetch and display contact image in background thread
        cell.imageView.image = nil;
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
        dispatch_async(queue, ^(void) {
            
            NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[contactsArray[indexPath.row] objectForKey:@"smallImageURL"]]];
            
            UIImage* image = [[UIImage alloc] initWithData:imageData];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                cell.imageView.image = image;
                [cell setNeedsLayout];
            });
        });
        
        cell.textLabel.text = [contactsArray[indexPath.row] objectForKey:@"name"];
        
        NSDictionary *dict = [contactsArray[indexPath.row] objectForKey:@"phone"];
        cell.detailTextLabel.text = [dict objectForKey:@"home"];
    }
    return cell;
}

#pragma mark <UITableViewDelegate>

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    // going to next view controller on tap of any cell
    ContactDetailsViewController *detailVC = [self.storyboard instantiateViewControllerWithIdentifier:@"detailView"];
    detailVC.contactDict = [contactsArray objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:detailVC animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 80.0;
}

// to set cell background color
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row % 2)
    {
        [cell setBackgroundColor:[UIColor colorWithRed:128/255.0 green:128/255.0 blue:128/255.0 alpha:1]];
    }
    else [cell setBackgroundColor:[UIColor colorWithRed:153/255.0 green:153/255.0 blue:153/255.0 alpha:1]];
}


@end
