//
//  ContactDetailsViewController.h
//  Solstice_Mobile
//
//  Created by Mayank Mathur on 3/2/17.
//  Copyright © 2017 Mayank Mathur. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactDetailsViewController : UIViewController{
    
    
}

//different labels for the UI requirement
@property (weak, nonatomic) IBOutlet UILabel *nameLbl;
@property (weak, nonatomic) IBOutlet UILabel *companyLbl;
@property (weak, nonatomic) IBOutlet UILabel *phoneLbl;
@property (weak, nonatomic) IBOutlet UILabel *add1Lbl;
@property (weak, nonatomic) IBOutlet UILabel *add2Lbl;
@property (weak, nonatomic) IBOutlet UILabel *birthdayLbl;
@property (weak, nonatomic) IBOutlet UILabel *emailLbl;
@property (weak, nonatomic) IBOutlet UIImageView *contactImage;

@property (weak, nonatomic) NSDictionary *contactDict;
@property (weak, nonatomic) IBOutlet UIImageView *favouriteImage;

- (IBAction)onTapShareBtn:(id)sender;

-(void) setValuesOfContact;

@end
