//
//  ContactsTableViewController.h
//  Solstice_Mobile
//
//  Created by Mayank Mathur on 3/2/17.
//  Copyright © 2017 Mayank Mathur. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContactsTableViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>{
    
    NSArray *contactsArray;
    
}

@property (weak, nonatomic) IBOutlet UITableView *contactsTableView;

-(void)sendRequest:(NSString*)url;

@end
