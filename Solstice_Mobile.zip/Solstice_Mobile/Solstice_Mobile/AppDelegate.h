//
//  AppDelegate.h
//  Solstice_Mobile
//
//  Created by Mayank Mathur on 3/2/17.
//  Copyright © 2017 Mayank Mathur. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

