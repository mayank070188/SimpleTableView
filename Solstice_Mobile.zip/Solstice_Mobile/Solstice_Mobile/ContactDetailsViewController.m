//
//  ContactDetailsViewController.m
//  Solstice_Mobile
//
//  Created by Mayank Mathur on 3/2/17.
//  Copyright © 2017 Mayank Mathur. All rights reserved.
//

#import "ContactDetailsViewController.h"

@interface ContactDetailsViewController ()

@end

@implementation ContactDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self setValuesOfContact];
}


- (IBAction)onTapShareBtn:(id)sender {
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"Share Contact" message:@"You can share the contact information with someone" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    [alertController addAction:ok];
    
    
    [alertController addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [self closeAlertview];
    }]];
    
    
    [self presentViewController:alertController animated:YES completion:nil];
}


-(void)closeAlertview
{
    
    [self dismissViewControllerAnimated:YES completion:nil];
}


// to display the contact values in the UI
-(void) setValuesOfContact{
    
    if ([_contactDict valueForKey:@"largeImageURL"] != nil)
    {
        // To fetch and display contact image in background thread
        _contactImage.image = nil;
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
        dispatch_async(queue, ^(void) {
            
            NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[_contactDict valueForKey:@"largeImageURL"]]];
            
            UIImage* image = [[UIImage alloc] initWithData:imageData];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                _contactImage.image = image;
                
            });
        });
    }
    
    _nameLbl.text = [_contactDict valueForKey:@"name"];
    _companyLbl.text = [_contactDict valueForKey:@"company"];
    
    // according to the fav value we get in feed
    int fav = [[_contactDict valueForKey:@"favorite"] intValue];
    if(fav == 0){
        _favouriteImage.image = [UIImage imageNamed:@"favorite.png"];
    }else{
        _favouriteImage.image = [UIImage imageNamed:@"remove_favorite.png"];
    }
    
    NSDictionary *dict = [_contactDict objectForKey:@"phone"];
    _phoneLbl.text = [dict valueForKey:@"home"];
  
    // formatting the date to show in required format
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:[[_contactDict valueForKey:@"birthdate"] integerValue]];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"MMMM dd, yyyy"]; // Change to suit your format
    NSString *stringFromDate = [dateFormatter stringFromDate:date];
    _birthdayLbl.text = stringFromDate;
    
    _emailLbl.text = [_contactDict valueForKey:@"email"];
    
    NSDictionary *dict1 = [_contactDict objectForKey:@"address"];
    _add1Lbl.text = [dict1 valueForKey:@"street"];
    _add2Lbl.text = [NSString stringWithFormat:@"%@, %@ %@",[dict1 valueForKey:@"city"],[dict1 valueForKey:@"state"],[dict1 valueForKey:@"zip"]];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
